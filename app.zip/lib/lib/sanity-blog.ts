import { client } from "@/sanity/lib/client";
import {
  blogPostBySlugQuery,
  blogPostSlugsQuery,
  blogPostsQuery,
} from "@/sanity/lib/queries";

export type SanityBlogPost = {
  _id?: string;
  slug: string;
  title: string;
  excerpt: string;
  publishedAt: string;
  updatedAt?: string;
  category?: string;
  categorySlug?: string;
  featured?: boolean;
  tags?: string[];
  readTime?: string;
  body?: unknown[];
  seoTitle?: string;
  seoDescription?: string;
  primaryKeyword?: string;
  seoKeywords?: string[];
  canonicalUrl?: string;
  seoNoIndex?: boolean;
  featuredImageUrl?: string;
  socialImageUrl?: string;
  featuredImage?: {
    url?: string;
    alt?: string;
    caption?: string;
  };
  author?: {
    name?: string;
    role?: string;
    bio?: string;
    slug?: string;
    linkedin?: string;
    website?: string;
    photo?: { url?: string; alt?: string };
  };
  relatedPosts?: Array<{
    _id: string;
    title: string;
    slug: string;
    excerpt?: string;
    category?: string;
    publishedAt?: string;
  }>;
};

export async function getSanityBlogPosts(): Promise<SanityBlogPost[]> {
  try {
    return await client.fetch<SanityBlogPost[]>(blogPostsQuery);
  } catch (error) {
    console.error("Failed to fetch Sanity blog posts:", error);
    return [];
  }
}

export async function getSanityBlogPost(
  slug: string
): Promise<SanityBlogPost | null> {
  try {
    return await client.fetch<SanityBlogPost | null>(blogPostBySlugQuery, { slug });
  } catch (error) {
    console.error(`Failed to fetch Sanity blog post "${slug}":`, error);
    return null;
  }
}

export async function getSanityBlogSlugs(): Promise<
  Array<{ slug: string; updatedAt?: string; publishedAt?: string }>
> {
  try {
    return await client.fetch<
      Array<{ slug: string; updatedAt?: string; publishedAt?: string }>
    >(blogPostSlugsQuery);
  } catch (error) {
    console.error("Failed to fetch Sanity blog slugs:", error);
    return [];
  }
}
