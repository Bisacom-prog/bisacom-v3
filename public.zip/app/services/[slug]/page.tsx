import type {Metadata} from "next";
import {notFound} from "next/navigation";
import Link from "next/link";
import {serviceDetails, type ServiceSlug} from "@/lib/services";
import {siteConfig} from "@/lib/site";

export function generateStaticParams(){return Object.keys(serviceDetails).map(slug=>({slug}))}

export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{
  const {slug}=await params; const service=serviceDetails[slug as ServiceSlug];
  if(!service)return {};
  const canonical = `${siteConfig.url}/services/${slug}`;
  return {
    title: service.title,
    description: service.description,
    alternates: {canonical},
    openGraph: {title: service.title, description: service.description, url: canonical, siteName: siteConfig.name, locale: siteConfig.locale, type: "website"},
    twitter: {card: "summary_large_image", title: service.title, description: service.description},
  };
}

export default async function ServicePage({params}:{params:Promise<{slug:string}>}){
  const {slug}=await params; const service=serviceDetails[slug as ServiceSlug]; if(!service)notFound();
  const mailSubject=encodeURIComponent(`${service.title} enquiry`);
  const serviceUrl = `${siteConfig.url}/services/${slug}`;
  const serviceStructuredData = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: service.title,
    description: service.description,
    url: serviceUrl,
    areaServed: ["Norwich", "United Kingdom", "Remote"],
    provider: {"@id": `${siteConfig.url}/#business`},
  };
  return <div className="min-h-screen bg-surface text-foreground">
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(serviceStructuredData)}} />
    <section className="bg-navy on-navy px-6 py-20 text-white lg:px-8"><div className="mx-auto max-w-5xl"><Link href="/services" className="text-sm font-bold text-accent-bright">← All services</Link><p className="eyebrow mt-12 text-accent-bright">{service.eyebrow}</p><div className="mt-4 grid gap-8 md:grid-cols-[1fr_auto] md:items-end"><div><h1 className="text-4xl font-bold md:text-6xl">{service.title}</h1><p className="mt-5 max-w-3xl text-lg leading-8 text-on-navy-muted">{service.description}</p></div><p className="rounded-full border border-white/15 px-5 py-3 text-sm font-bold">{service.price}</p></div></div></section>
    <section className="px-6 py-20 lg:px-8"><div className="mx-auto grid max-w-5xl gap-12 lg:grid-cols-2"><div><p className="eyebrow">Best for</p><p className="mt-4 text-lg leading-8 text-muted">{service.audience}</p><p className="eyebrow mt-10">Typical duration</p><p className="mt-4 font-bold">{service.duration}</p></div><div><p className="eyebrow">What you receive</p><ul className="mt-5 space-y-4">{service.deliverables.map(x=><li key={x} className="flex gap-3 leading-7"><b className="text-accent-ink">✓</b>{x}</li>)}</ul></div></div></section>
    <section className="bg-surface-muted px-6 py-20 lg:px-8"><div className="mx-auto max-w-5xl"><p className="eyebrow">How it works</p><h2 className="mt-3 text-3xl font-bold">A clear path from brief to delivery</h2><ol className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">{service.process.map((step,i)=><li key={step} className="rounded-2xl border border-line bg-surface p-6"><span className="text-xs font-bold text-accent-ink">0{i+1}</span><p className="mt-4 text-sm leading-7">{step}</p></li>)}</ol></div></section>
    <section className="px-6 py-20 lg:px-8"><div className="mx-auto max-w-5xl rounded-xl bg-navy on-navy p-8 text-white md:flex md:items-center md:justify-between md:p-12"><div><p className="eyebrow text-accent-bright">Ready to discuss it?</p><h2 className="mt-3 text-3xl font-bold">Start with your goal and current challenge.</h2></div><div className="mt-7 flex flex-col gap-3 sm:flex-row md:mt-0"><a href={`mailto:hello@bisacom.dev?subject=${mailSubject}`} className="rounded-xl bg-accent px-6 py-4 text-center text-sm font-bold text-on-accent">Email enquiry</a><a href="https://wa.me/447555824637?text=Hello%20Bismark%2C%20I%27d%20like%20to%20discuss%20a%20project." className="rounded-xl border border-white/20 px-6 py-4 text-center text-sm font-bold">WhatsApp</a></div></div></section>
  </div>
}
